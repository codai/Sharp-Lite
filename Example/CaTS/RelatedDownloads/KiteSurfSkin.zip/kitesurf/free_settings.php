<?php

$email_to = "youremailaddress@yourdomain.com"; // your email address
$email_subject = "Contact Form Message"; // email subject line
$thankyou = "thankyou.htm"; // thank you page

?>